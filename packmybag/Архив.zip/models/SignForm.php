<?php

namespace app\models;

use yii\base\Model;

class SignForm extends Model
{
    public $email;

    public function rules()
    {
    }
}