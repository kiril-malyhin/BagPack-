<?php

/* @var $this yii\web\View */

$this->title = 'BagPack';
?>
<div class="site-index">

    <div class="jumbotron">
        <div class="home-name">
            <h1>Do You travel a lot?</h1>
            <p class="lead">So the main question is:</p>
        </div>
        <div class="home-start">
            <a href = "index.php?r=pack/create" class="btn btn-lg btn-default">Start packing <span class="glyphicon glyphicon-check"></span></a>
        </div>

    </div>

</div>
