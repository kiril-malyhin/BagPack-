$(window).resize(function() {
    if ($(window).width() <= 600) {
        $('#prop-type-group').removeClass('btn-group');
        $('#prop-type-group').addClass('btn-group-vertical');
    } else {
        $('#prop-type-group').addClass('btn-group');
        $('#prop-type-group').removeClass('btn-group-vertical');
    }
});